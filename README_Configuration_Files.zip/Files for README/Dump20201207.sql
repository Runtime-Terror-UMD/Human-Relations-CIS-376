-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: dbo
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activitylog`
--

DROP TABLE IF EXISTS `activitylog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activitylog` (
  `activityLogID` int unsigned NOT NULL AUTO_INCREMENT,
  `effectedUser` int unsigned NOT NULL,
  `activityTypeID` int NOT NULL,
  `refID` int DEFAULT NULL,
  `created` datetime NOT NULL,
  `createdBy` int unsigned NOT NULL,
  PRIMARY KEY (`activityLogID`),
  KEY `activityLog_activityType_FK_idx` (`activityTypeID`),
  CONSTRAINT `activityLog_activityType_FK` FOREIGN KEY (`activityTypeID`) REFERENCES `activitytype` (`activityTypeID`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Log of activity';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activitylog`
--

LOCK TABLES `activitylog` WRITE;
/*!40000 ALTER TABLE `activitylog` DISABLE KEYS */;
INSERT INTO `activitylog` VALUES (6,13,14,13,'2020-10-27 00:00:00',13),(7,12,14,12,'2020-10-27 00:00:00',12),(8,14,14,14,'2020-10-28 00:00:00',12),(9,13,1,13,'2020-10-31 00:00:00',3),(10,13,1,13,'2020-10-31 00:00:00',3),(11,13,1,13,'2020-10-31 00:00:00',3),(12,13,1,13,'2020-10-31 00:00:00',3),(13,13,1,13,'2020-10-31 00:00:00',3),(14,15,14,15,'2020-11-03 00:00:00',3),(15,15,14,15,'2020-11-03 00:00:00',15),(16,16,14,16,'2020-11-04 00:00:00',3),(17,16,14,16,'2020-11-04 00:00:00',16),(18,16,2,16,'2020-11-04 00:00:00',16),(19,16,9,16,'2020-11-04 00:00:00',16),(20,16,9,16,'2020-11-04 00:00:00',16),(21,16,9,16,'2020-11-04 00:00:00',16),(22,3,2,3,'2020-11-05 00:00:00',3),(23,14,15,1,'2020-11-12 00:00:00',15),(24,11,15,2,'2020-11-12 00:00:00',15),(25,10,15,3,'2020-11-12 00:00:00',15),(32,11,17,2,'2020-11-12 00:00:00',15),(33,11,17,2,'2020-11-12 00:00:00',15),(34,14,17,1,'2020-11-12 00:00:00',15),(36,6,16,5,'2020-11-12 00:00:00',15),(37,6,17,5,'2020-11-12 00:00:00',15),(38,6,17,5,'2020-11-12 00:00:00',15),(39,11,15,11,'2020-11-12 00:00:00',11),(40,11,15,11,'2020-11-12 00:00:00',11),(41,11,15,11,'2020-11-12 00:00:00',11),(42,10,15,10,'2020-11-12 00:00:00',10),(43,10,2,10,'2020-11-12 00:00:00',10),(44,14,15,14,'2020-11-13 00:00:00',14),(45,4,15,4,'2020-11-13 00:00:00',4),(46,3,15,3,'2020-11-13 00:00:00',3),(47,6,15,6,'2020-11-13 00:00:00',6),(48,13,16,8,'2020-11-13 00:00:00',4),(49,13,16,9,'2020-11-13 00:00:00',3),(50,5,15,5,'2020-11-17 00:00:00',5),(51,16,15,16,'2020-11-18 00:00:00',16),(52,16,18,1,'2020-11-18 00:00:00',16),(53,16,18,2,'2020-11-18 00:00:00',16),(54,16,18,2,'2020-11-24 00:00:00',16),(55,5,18,5,'2020-11-26 00:00:00',5),(56,5,18,5,'2020-11-26 00:00:00',5),(57,5,18,5,'2020-11-26 00:00:00',5),(58,5,18,5,'2020-11-26 00:00:00',5),(59,5,18,5,'2020-11-26 00:00:00',5),(60,5,18,10,'2020-11-26 00:00:00',5),(61,5,18,10,'2020-11-26 00:00:00',5),(62,13,17,8,'2020-12-04 00:00:00',3),(63,3,13,0,'2020-12-04 00:00:00',3),(64,15,13,0,'2020-12-05 00:00:00',15),(65,15,13,0,'2020-12-05 00:00:00',15),(66,3,13,0,'2020-12-05 00:00:00',3),(67,3,13,0,'2020-12-05 00:00:00',3),(68,3,18,12,'2020-12-05 00:00:00',3),(69,3,13,0,'2020-12-05 00:00:00',3),(70,3,13,0,'2020-12-05 00:00:00',3),(71,3,13,0,'2020-12-05 00:00:00',3),(72,10,13,0,'2020-12-05 00:00:00',10),(73,3,13,0,'2020-12-06 00:00:00',3),(74,3,13,0,'2020-12-06 00:00:00',3),(75,17,14,17,'2020-12-06 00:00:00',3),(76,3,13,0,'2020-12-06 00:00:00',3),(77,18,14,18,'2020-12-06 00:00:00',3),(78,3,13,0,'2020-12-06 00:00:00',3),(79,18,15,18,'2020-12-06 00:00:00',18),(80,3,12,0,'2020-12-06 00:00:00',3),(81,3,12,0,'2020-12-06 00:00:00',3),(82,3,13,0,'2020-12-06 00:00:00',3);
/*!40000 ALTER TABLE `activitylog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activitytype`
--

DROP TABLE IF EXISTS `activitytype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activitytype` (
  `activityTypeID` int NOT NULL,
  `activityTypeDescription` varchar(100) NOT NULL,
  PRIMARY KEY (`activityTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Details for types of activities';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activitytype`
--

LOCK TABLES `activitytype` WRITE;
/*!40000 ALTER TABLE `activitytype` DISABLE KEYS */;
INSERT INTO `activitytype` VALUES (1,'updated employee profile'),(2,'updated personal profile'),(3,'updated role'),(4,'updated department'),(5,'updated active status'),(6,'updated pay rate'),(7,'approved leave request'),(8,'denied leave request'),(9,'changed password'),(10,'changed username'),(11,'updated time log'),(12,'logged in'),(13,'logged out'),(14,'created new account'),(15,'verified account'),(16,'create schedule'),(17,'updated schedule'),(18,'made leave request'),(19,'deleted schedule');
/*!40000 ALTER TABLE `activitytype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `depID` int NOT NULL AUTO_INCREMENT,
  `depName` varchar(50) NOT NULL,
  `isActive` bit(1) DEFAULT NULL,
  PRIMARY KEY (`depID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'Administration',NULL),(2,'Executive',NULL),(3,'Finance',NULL),(4,'Human Resources',NULL),(5,'Information Technology',NULL),(6,'Maintenance',NULL),(7,'Productions',NULL),(8,'Projects',NULL),(9,'Quality',NULL),(10,'Research',NULL),(11,'Sales',NULL),(12,'Security',NULL);
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leavemgmt`
--

DROP TABLE IF EXISTS `leavemgmt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leavemgmt` (
  `leaveID` int NOT NULL AUTO_INCREMENT,
  `userID` int NOT NULL,
  `dateStart` date NOT NULL,
  `dateEnd` date NOT NULL,
  `approvalStatus` varchar(45) NOT NULL,
  `created` datetime NOT NULL,
  `processedBy` int DEFAULT NULL,
  `processedTime` datetime DEFAULT NULL,
  `applyPTO` varchar(45) NOT NULL,
  PRIMARY KEY (`leaveID`),
  KEY `leavemgmt_user_FK_idx` (`userID`),
  CONSTRAINT `leavemgmt_user_FK` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leavemgmt`
--

LOCK TABLES `leavemgmt` WRITE;
/*!40000 ALTER TABLE `leavemgmt` DISABLE KEYS */;
INSERT INTO `leavemgmt` VALUES (10,5,'2020-12-27','2020-12-28','approved','2020-11-26 17:17:44',NULL,NULL,'Yes'),(11,6,'2020-12-29','2021-01-01','approved','2020-11-26 17:18:38',NULL,NULL,'Yes'),(12,3,'2020-12-24','2021-01-02','approved','2020-12-05 16:20:38',NULL,NULL,'Yes');
/*!40000 ALTER TABLE `leavemgmt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `notificationID` int NOT NULL AUTO_INCREMENT,
  `notificationText` varchar(500) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date DEFAULT NULL,
  `createdBy` int NOT NULL,
  `AdminOnlyNotification` bit(1) NOT NULL,
  `isActive` bit(1) NOT NULL,
  PRIMARY KEY (`notificationID`),
  KEY `notifications_user_FK_idx` (`createdBy`),
  CONSTRAINT `notifications_user_FK` FOREIGN KEY (`createdBy`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (4,'Pending Leave Requests','2020-12-05','2020-12-07',15,_binary '',_binary '\0'),(5,'Pending Leave Requests','2020-12-05','2020-12-07',15,_binary '',_binary '\0'),(6,'Pending Leave Requests','2020-12-05','2020-12-07',3,_binary '',_binary '\0');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payperiods`
--

DROP TABLE IF EXISTS `payperiods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payperiods` (
  `payPeriodID` int NOT NULL,
  `monthNo` int NOT NULL,
  `startDate` int NOT NULL,
  `endDate` int NOT NULL,
  `payPeriodName` varchar(45) NOT NULL,
  PRIMARY KEY (`payPeriodID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payperiods`
--

LOCK TABLES `payperiods` WRITE;
/*!40000 ALTER TABLE `payperiods` DISABLE KEYS */;
INSERT INTO `payperiods` VALUES (1,1,1,14,'1/1/2020 - 1/14/2020'),(2,1,15,31,'1/15/2020 - 1/31/2020'),(3,2,1,14,'2/1/2020 - 2/14/2020'),(4,2,15,29,'2/15/2020 - 2/29/2020'),(5,3,1,14,'3/1/2020 - 3/14/2020'),(6,3,15,31,'3/15/2020 - 3/31/2020'),(7,4,1,14,'4/1/2020 - 4/14/2020'),(8,4,15,30,'4/15/2020 - 4/30/2020'),(9,5,1,14,'5/1/2020 - 5/14/2020'),(10,5,15,31,'5/15/2020 - 5/31/2020'),(11,6,1,14,'6/1/2020 - 6/14/2020'),(12,6,15,30,'6/15/2020 - 6/30/2020'),(13,7,1,14,'7/1/2020 - 7/14/2020'),(14,7,15,31,'7/15/2020 - 7/31/2020'),(15,8,1,14,'8/1/2020 - 8/14/2020'),(16,8,15,31,'8/15/2020 - 8/31/2020'),(17,9,1,14,'9/1/2020 - 9/14/2020'),(18,9,15,30,'9/15/2020 - 9/30/2020'),(19,10,1,14,'10/1/2020 - 10/14/2020'),(20,10,15,31,'10/15/2020 - 10/31/2020'),(21,11,1,14,'11/1/2020 - 11/14/2020'),(22,11,15,30,'11/15/2020 - 11/30/2020'),(23,12,1,14,'12/1/2020 - 12/14/2020'),(24,12,15,31,'12/14/2020 - 12/31/2020');
/*!40000 ALTER TABLE `payperiods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `roleID` int NOT NULL AUTO_INCREMENT,
  `roleName` varchar(50) NOT NULL,
  `isActive` bit(1) DEFAULT NULL,
  PRIMARY KEY (`roleID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Associate Staff',NULL),(2,'Intermediate Staff',NULL),(3,'Senior Staff',NULL),(4,'Manager',NULL),(5,'Senior Manger',NULL),(6,'Advisor',NULL),(7,'Senior Advisor',NULL),(8,'Executive',NULL),(9,'Senior Executive',NULL),(10,'Director',NULL),(11,'Senior Director',NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `scheduleID` int NOT NULL AUTO_INCREMENT,
  `userID` int NOT NULL,
  `InDateTime` datetime NOT NULL,
  `outDateTime` datetime NOT NULL,
  PRIMARY KEY (`scheduleID`),
  KEY `FK_schedule_user_idx` (`userID`),
  CONSTRAINT `FK_schedule_user` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,14,'2020-11-13 02:00:00','2020-11-13 15:00:00'),(2,11,'2020-11-13 05:00:00','2020-11-13 11:30:00'),(3,10,'2020-11-14 18:00:00','2020-11-15 01:00:00'),(4,5,'2020-11-14 15:00:00','2020-11-14 19:00:00'),(5,6,'2020-11-16 18:00:00','2020-11-16 18:01:00'),(9,13,'2020-11-14 20:44:34','2020-11-14 22:44:34');
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetracking`
--

DROP TABLE IF EXISTS `timetracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timetracking` (
  `logID` int NOT NULL AUTO_INCREMENT,
  `userID` int NOT NULL,
  `payPeriodID` int NOT NULL,
  `inDateTime` datetime NOT NULL,
  `outDateTime` datetime DEFAULT NULL,
  `totalPay` double DEFAULT NULL,
  `shifton` int DEFAULT NULL,
  PRIMARY KEY (`logID`),
  KEY `FK_timetracking_user_idx` (`userID`),
  KEY `FK_timetracking_payPeriod_idx` (`payPeriodID`),
  CONSTRAINT `FK_timetracking_payperiod` FOREIGN KEY (`payPeriodID`) REFERENCES `payperiods` (`payPeriodID`),
  CONSTRAINT `FK_timetracking_user` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetracking`
--

LOCK TABLES `timetracking` WRITE;
/*!40000 ALTER TABLE `timetracking` DISABLE KEYS */;
INSERT INTO `timetracking` VALUES (7,3,21,'2020-11-03 18:45:55','2020-11-03 19:15:00',NULL,0),(8,3,21,'2020-11-03 18:56:32','2020-11-03 19:15:00',NULL,0),(9,3,21,'2020-11-03 18:59:23','2020-11-03 19:15:00',NULL,0),(10,3,21,'2020-11-03 19:10:25','2020-11-03 19:15:00',NULL,0),(11,3,21,'2020-11-03 19:12:53','2020-11-03 19:15:00',NULL,0),(12,3,21,'2020-11-03 19:14:06','2020-11-03 19:15:00',NULL,0),(13,3,21,'2020-11-03 19:14:58','2020-11-03 19:15:00',NULL,0),(14,3,21,'2020-11-03 19:16:21','2020-11-03 19:37:12',NULL,0),(15,12,21,'2020-11-03 19:27:31','2020-11-03 19:32:49',NULL,0),(16,3,21,'2020-11-03 19:43:37','2020-11-03 19:43:46',NULL,0),(17,15,21,'2020-11-03 19:52:30','2020-11-03 19:52:46',NULL,0),(18,15,21,'2020-11-05 18:00:00','2020-11-05 19:38:35',NULL,0),(19,15,21,'2020-11-05 19:37:48','2020-11-05 19:37:49',NULL,0),(20,3,21,'2020-11-05 18:00:20','2020-11-05 19:42:58',171.7,0),(21,15,22,'2020-11-17 18:23:09','2020-11-17 19:23:42',1000,0),(22,3,22,'2020-11-24 13:22:56','2020-11-24 14:23:24',101,0),(23,3,22,'2020-11-24 14:29:38','2020-11-24 14:29:45',0,0),(24,5,22,'2020-11-23 12:18:54','2020-11-23 17:18:54',100,0),(25,15,22,'2020-11-29 12:24:52','2020-11-29 12:24:54',0,0),(28,5,22,'2020-11-29 00:00:00','2020-11-30 00:00:00',250,0),(29,5,22,'2020-11-29 00:00:00','2020-11-30 00:00:00',250,0),(30,5,22,'2020-12-30 00:00:00','2021-01-01 00:00:00',200,0),(31,5,22,'2020-11-29 00:00:00','2020-12-01 00:00:00',250,0),(32,5,22,'2020-11-27 00:00:00','2020-11-28 00:00:00',1000,0),(33,6,22,'2020-11-29 00:00:00','2020-12-01 00:00:00',1600,0),(34,6,22,'2020-11-29 00:00:00','2020-12-01 00:00:00',1600,0),(35,5,22,'2020-11-27 00:00:00','2020-11-28 00:00:00',1000,0),(36,5,22,'2020-11-27 00:00:00','2020-11-28 00:00:00',1000,0),(37,6,22,'2020-11-29 00:00:00','2020-12-01 00:00:00',1600,0),(38,5,24,'2020-12-27 00:00:00','2020-12-28 00:00:00',1000,0),(39,6,24,'2020-12-29 00:00:00','2020-11-01 00:00:00',46400,0),(40,6,24,'2020-12-29 00:00:00','2020-11-01 00:00:00',46400,0),(41,5,24,'2020-12-27 00:00:00','2020-12-28 00:00:00',1000,0),(42,6,24,'2020-12-29 00:00:00','2021-01-01 00:00:00',1600,0),(43,5,24,'2020-12-27 00:00:00','2020-12-28 00:00:00',1000,0),(44,6,24,'2020-12-29 00:00:00','2021-01-01 00:00:00',0,0),(45,6,24,'2020-12-29 00:00:00','2021-01-01 00:00:00',0,0),(46,6,24,'2020-12-29 00:00:00','2021-01-01 00:00:00',1500,0),(47,3,24,'2020-12-24 00:00:00','2021-01-02 00:00:00',14.14,0);
/*!40000 ALTER TABLE `timetracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `isAdmin` bit(1) NOT NULL,
  `isActive` bit(1) DEFAULT NULL,
  `hireDate` datetime NOT NULL,
  `lastDate` datetime DEFAULT NULL,
  `payRate` decimal(10,2) NOT NULL,
  `roleID` int NOT NULL DEFAULT '0',
  `depID` int NOT NULL DEFAULT '0',
  `ptoTime` decimal(10,2) NOT NULL DEFAULT '0.00',
  `address1` varchar(45) DEFAULT NULL,
  `address2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `zip` int DEFAULT NULL,
  `phoneNum` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `customerID_UNIQUE` (`userID`),
  KEY `user_role_FK_idx` (`roleID`),
  KEY `user_department_FK_idx` (`depID`),
  CONSTRAINT `user_department_FK` FOREIGN KEY (`depID`) REFERENCES `department` (`depID`),
  CONSTRAINT `user_role_FK` FOREIGN KEY (`roleID`) REFERENCES `role` (`roleID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='user profile information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (2,'Lynsey','Nguyen','lynseyn@umich.edu','lynseyn','test1',_binary '',_binary '','2020-10-25 00:00:00',NULL,100.00,1,1,0.00,NULL,NULL,NULL,NULL,NULL,NULL),(3,'a','b','username5@email.com','ab','c',_binary '',_binary '','2020-11-02 23:59:54','0001-01-01 00:00:00',101.00,6,9,0.00,'123 test street','','test town','MS',11111,'(111) 111-1111'),(4,'first','last','firstlast@company.org','firstlast','a',_binary '',_binary '','2020-11-03 20:29:50',NULL,102.00,4,5,0.00,'22 abc','','test','MN',11111,'(111) 111-1111'),(5,'one','two','email@gmail.com','username','password',_binary '\0',_binary '','2020-10-28 20:34:37',NULL,125.00,1,6,8.00,'123','','townville','MD',44444,'(444) 444-4444'),(6,'another','one','one@email.com','one','abc',_binary '\0',_binary '','2020-10-29 20:36:34',NULL,100.00,2,7,0.00,'22','22','22','MN',11111,'(111) 111-1111'),(7,'first','last','user@emai.com','user','pass',_binary '\0',_binary '','2020-11-05 20:39:41',NULL,100.00,3,10,0.00,NULL,NULL,NULL,NULL,NULL,NULL),(8,'first','last','user@email.com','user','pass',_binary '',_binary '','2020-10-28 20:47:53',NULL,100.00,3,8,0.00,NULL,NULL,NULL,NULL,NULL,NULL),(9,'first','last','username@gmail.com','username1','pass',_binary '',_binary '','2020-10-27 21:01:36',NULL,100.00,4,2,0.00,NULL,NULL,NULL,NULL,NULL,NULL),(10,'Francine','Lazlo','username@email.com','username3','pass3',_binary '\0',_binary '','2020-10-27 21:29:22','0001-01-01 00:00:00',100.00,5,8,0.00,'894 Doctorate','','Westminister','CA',19543,'(516) 842-1356'),(11,'Frank','Long','username5@email.com','username5','pass4',_binary '\0',_binary '','2020-10-29 21:34:17','0001-01-01 00:00:00',100.00,5,5,0.00,'4901 Evergreen','5','Dearborn','ME',48182,'(146) 512-3546'),(12,'Test','Admin','email123@gmail.com','username7','password',_binary '',_binary '','2020-10-29 21:39:58','0001-01-01 00:00:00',100.00,6,7,0.00,'221 Baker Street','Apt. 2B','London','AK',12345,'(111) 111-1111'),(13,'mariam','bitar','mbitar@gmail.com','mbitar','test',_binary '\0',_binary '\0','2020-11-05 21:44:00','2020-10-31 16:30:55',100.25,4,2,0.00,'123 Test','','Test','AK',12345,'(111) 111-1111'),(14,'Bill ','Nye','bill@science.org','thescienceguy','a',_binary '\0',_binary '','2020-10-28 01:30:23','0001-01-01 00:00:00',1.00,2,2,0.00,'123 test street','','new york','NH',11111,'(111) 111-1111'),(15,'Samera','Hobe','hsamera@marte.com','hsamera','emali',_binary '',_binary '','2020-11-03 19:49:09','0001-01-01 00:00:00',1000.00,9,2,0.05,'1 albe','','8aram','MI',48141,'(111) 111-1111'),(16,'Jacky','Daytona','jdaytona@arizoya.com','jdaytona','c',_binary '\0',_binary '','2020-11-04 00:22:15','0001-01-01 00:00:00',11.00,1,9,5.00,'123 test','','city','NV',12345,'(123) 456-7890'),(17,'first','last','employee123@gmail.com','employee123','pass',_binary '\0',_binary '','2020-12-06 11:00:59',NULL,40.00,1,1,0.00,NULL,NULL,NULL,NULL,NULL,NULL),(18,'Mariam','Bitar','mbitar5@gmail.com','mbitar5','pass2',_binary '\0',_binary '','2020-12-06 11:04:07',NULL,20.00,1,1,0.00,'123 street','','city','ID',12345,'(313) 111-1111');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-07 15:15:22
